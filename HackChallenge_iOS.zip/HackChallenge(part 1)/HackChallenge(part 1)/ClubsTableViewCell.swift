//
//  ClubsTableViewCell.swift
//  HackChallenge(part 1)
//
//  Created by Alvaro on 5/5/19.
//  Copyright © 2019 Alvaro Echevarria Cuesta. All rights reserved.
//

import UIKit

class ClubsTableViewCell: UITableViewCell {

    var nameLabel : UILabel!
    var blackView : UIView!
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        //background view
        blackView = UIView()
        blackView.translatesAutoresizingMaskIntoConstraints = false
        blackView.backgroundColor = .black
        contentView.addSubview(blackView)
        
        //nameLabel
        nameLabel = UILabel()
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.textAlignment = .center
        nameLabel.adjustsFontForContentSizeCategory = true
        nameLabel.textColor = .black
        nameLabel.backgroundColor = .gray
        contentView.addSubview(nameLabel)
        
        setupConstraints()
    }
    
    func setupConstraints() {
        //blackView
        NSLayoutConstraint.activate([
            blackView.topAnchor.constraint(equalTo: contentView.topAnchor),
            blackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            blackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            blackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
            ])
        //nameLabel
        NSLayoutConstraint.activate([
            nameLabel.bottomAnchor.constraint(equalTo: blackView.bottomAnchor, constant: -1),
            nameLabel.topAnchor.constraint(equalTo: blackView.topAnchor, constant: 1),
            nameLabel.leadingAnchor.constraint(equalTo: blackView.leadingAnchor, constant: 1),
            nameLabel.trailingAnchor.constraint(equalTo: blackView.trailingAnchor, constant: -1)
            ])
    }
    
    func configurecell(for name: String){
        nameLabel.text = name        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
