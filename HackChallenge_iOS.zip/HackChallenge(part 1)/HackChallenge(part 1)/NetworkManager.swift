//
//  NetworkManager.swift
//  HackChallenge(part 1)
//
//  Created by Alvaro on 5/5/19.
//  Copyright © 2019 Alvaro Echevarria Cuesta. All rights reserved.
//

import Foundation
import Alamofire

let endpoint_clubs = "http://35.237.190.115/api/clubs/"
let endpoint_events = "http://35.237.190.115/api/club/"


class NetworkManager {
    
    static func getClubs(completion: @escaping ([Club]) -> Void ) {
        Alamofire.request(endpoint_clubs, method: .get).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                if let yes = try? jsonDecoder.decode(BiggerPicture.self, from: data){
                    let clubs = yes.data.clubs
                    print("success")
                    completion(clubs)
                    print("\(clubs)")
                }
                else {
                    print("not succesful")
                }
                if let json = try? JSONSerialization.jsonObject(with: data, options: []){
                    print(json)
                }
            case .failure(let error):
                print("error! \(error.localizedDescription)")
                
                
            }
            
        }
    }
    static func getEvents(id: Int, completion: @escaping ([Events])-> Void ){
        let str = "\(id)/events/"
        let endpoint = endpoint_events + str
        Alamofire.request(endpoint, method: .get).validate().responseData { (response) in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                if let yes = try? jsonDecoder.decode(EventsBigPicture.self, from: data){
                    let events = yes.data.events
                    print("success")
                    completion(events)
                    print("\(events)")
                }
                else {
                    print("not succesful")
                }
            case .failure(let error):
                print("error! \(error.localizedDescription)")
        }
    }
}
    
    static func getmyclubs(){
        
    }
}
