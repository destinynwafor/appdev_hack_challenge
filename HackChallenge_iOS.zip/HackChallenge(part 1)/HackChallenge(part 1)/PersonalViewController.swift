//
//  PersonalViewController.swift
//  HackChallenge(part 1)
//
//  Created by Alvaro on 5/2/19.
//  Copyright © 2019 Alvaro Echevarria Cuesta. All rights reserved.
//

import UIKit

class PersonalViewController: UIViewController {
    var myclubLabel : UILabel!
    var label : UILabel!
    var myeventLabel : UILabel!
    var clubTableView : UITableView!
    var eventCollectionView : UICollectionView!
    var refreshButton : UIButton!
    
    var clubs : [Club]!
    var events : [Events]!
    let reusableId = "yes"
    let reusableIdCell = "no"
    
    let padding : CGFloat = 10
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        title = "Personal"
        view.backgroundColor = .gray
        
        
        //myclubLabel
        myclubLabel = UILabel()
        myclubLabel.translatesAutoresizingMaskIntoConstraints = false
        myclubLabel.text = "My Clubs"
        myclubLabel.textColor = .black
        myclubLabel.textAlignment = .left
        myclubLabel.backgroundColor = .gray
        myclubLabel.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        view.addSubview(myclubLabel)
        
        //clubTableView
        clubTableView = UITableView()
        clubTableView.translatesAutoresizingMaskIntoConstraints = false
        clubTableView.backgroundColor = .gray
        clubTableView.register(ClubsTableViewCell.self, forCellReuseIdentifier: reusableId)
        clubTableView.delegate = self
        clubTableView.dataSource = self
        view.addSubview(clubTableView)
        
        //myeventLabel
        myeventLabel = UILabel()
        myeventLabel.translatesAutoresizingMaskIntoConstraints = false
        myeventLabel.text = "My Events"
        myeventLabel.textColor = .black
        myeventLabel.textAlignment = .left
        myeventLabel.backgroundColor = .gray
        myeventLabel.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        view.addSubview(myeventLabel)
        
        //refreshButton
        refreshButton = UIButton()
        refreshButton.translatesAutoresizingMaskIntoConstraints = false
        refreshButton.setTitle("Refresh", for: .normal)
        refreshButton.titleLabel?.adjustsFontForContentSizeCategory = true
        refreshButton.layer.cornerRadius = 4
        refreshButton.backgroundColor = .cornellred
        refreshButton.setTitleColor(.black, for: .normal)
        refreshButton.addTarget(self, action: #selector(refreshPressed), for: .touchUpInside)
        view.addSubview(refreshButton)
//
//        // cell Layout
//        let eventLayout = UICollectionViewFlowLayout()
//        eventLayout.scrollDirection = .horizontal
//        eventLayout.minimumLineSpacing = padding
//        eventLayout.minimumInteritemSpacing = padding
//
//        eventCollectionView = UICollectionView(frame: .zero, collectionViewLayout: eventLayout)
//        eventCollectionView.translatesAutoresizingMaskIntoConstraints = false
//        eventCollectionView.backgroundColor = .gray
//        eventCollectionView.dataSource = self
//        eventCollectionView.delegate = self
//        eventCollectionView.register(EventCollectionViewCell.self, forCellWithReuseIdentifier: reusableIdCell)
//        view.addSubview(eventCollectionView)
//
//
        
        setupConstraints()
    }
    
    func setupConstraints() {
        //myclub setup
        NSLayoutConstraint.activate([
            myclubLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: padding),
            myclubLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            myclubLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -100),
            myclubLabel.heightAnchor.constraint(equalToConstant: 25)
            ])
        //rereshButton setup
        NSLayoutConstraint.activate([
            refreshButton.topAnchor.constraint(equalTo: myclubLabel.topAnchor),
            refreshButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding),
            refreshButton.heightAnchor.constraint(equalTo: myclubLabel.heightAnchor),
            refreshButton.widthAnchor.constraint(equalToConstant: 70)
            ])
        //clubTableView setup
        NSLayoutConstraint.activate([
            clubTableView.topAnchor.constraint(equalTo: myclubLabel.bottomAnchor, constant: padding),
            clubTableView.bottomAnchor.constraint(equalTo: myeventLabel.topAnchor, constant: -padding),
            clubTableView.leadingAnchor.constraint(equalTo: myclubLabel.leadingAnchor, constant: padding),
            clubTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -(2*padding))
            ])
        //myevent setup
        NSLayoutConstraint.activate([
            myeventLabel.topAnchor.constraint(equalTo: view.centerYAnchor , constant: 100),
            myeventLabel.leadingAnchor.constraint(equalTo: myclubLabel.leadingAnchor),
            myeventLabel.trailingAnchor.constraint(equalTo: myclubLabel.trailingAnchor),
            myeventLabel.heightAnchor.constraint(equalToConstant: 25)
            ])
//        //eventCollectionView
//        NSLayoutConstraint.activate([
//            eventCollectionView.topAnchor.constraint(equalTo: myeventLabel.bottomAnchor, constant: padding),
//            eventCollectionView.leadingAnchor.constraint(equalTo: clubTableView.leadingAnchor),
//            eventCollectionView.trailingAnchor.constraint(equalTo: clubTableView.trailingAnchor),
//            eventCollectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -padding)
//            ])
//
    }
    
    func getEvents(for id: Int){
        NetworkManager.getEvents(id: id) { (response) in
            self.events = self.events + response
            DispatchQueue.main.async {
                self.eventCollectionView.reloadData()
            }
        }

    }
    
    @objc func refreshPressed(){
        
        if (self.clubs == nil) {
        print("nothing in her b")
        }
        else {
            let length = (clubs.count)-1
            for i in 0...length {
                let id = self.clubs[i].id
                getEvents(for: id)
            }
        }
        
    }

}


extension PersonalViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (clubs == nil) {
            return 0
        }
        else{
        return clubs.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = clubTableView.dequeueReusableCell(withIdentifier: reusableId, for: indexPath) as! ClubsTableViewCell
        cell.configurecell(for: clubs[indexPath.row].name)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55
        
    }
}


extension PersonalViewController: UITableViewDelegate {
    
}


extension PersonalViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return events.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = eventCollectionView.dequeueReusableCell(withReuseIdentifier: reusableIdCell, for: indexPath) as! EventCollectionViewCell
        cell.configureEventCell(for: events[indexPath.item])
        return cell
    }


}

extension PersonalViewController : UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (eventCollectionView.frame.width-10) / 2
        let height = (eventCollectionView.frame.height-40)
        return CGSize(width: width, height: height)
    }
}

extension PersonalViewController : UICollectionViewDelegate {

}
