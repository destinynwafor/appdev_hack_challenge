//
//  ClubClass.swift
//  HackChallenge(part 1)
//
//  Created by Alvaro on 4/24/19.
//  Copyright © 2019 Alvaro Echevarria Cuesta. All rights reserved.
//

import Foundation
import UIKit

struct Club : Codable{
    var id : Int
    var name : String
    var description : String
}

struct ClubData : Codable {
    var clubs : [Club]
}

struct BiggerPicture :Codable {
    var data : ClubData
    var success : Bool
}




struct Events : Codable {
    var id : Int
    var description: String
    var start_datetime : String
    var end_datetime : String
}

struct EventsArray : Codable {
    var  events : [Events]
}

struct EventsBigPicture : Codable {
    var data : EventsArray
    var success : Bool
    
}
