//
//  File.swift
//  HackChallenge(part 1)
//
//  Created by Alvaro on 4/25/19.
//  Copyright © 2019 Alvaro Echevarria Cuesta. All rights reserved.
//

import Foundation
import UIKit


extension UIColor {
    @nonobjc static let cornellred = UIColor(red: 216/255, green: 14/255, blue: 14/255, alpha: 1)
}


