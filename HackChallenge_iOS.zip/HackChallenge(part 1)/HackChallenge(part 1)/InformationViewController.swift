//
//  InformationViewController.swift
//  HackChallenge(part 1)
//
//  Created by Alvaro on 4/24/19.
//  Copyright © 2019 Alvaro Echevarria Cuesta. All rights reserved.
//

import UIKit

class InformationViewController: UIViewController {
    var nameLabel : UILabel!
    var eventLabel : UILabel!
    var officersLabel : UILabel!
    var descriptionLabel : UILabel!
    var officersTextView : UITextView!
    var descriptionText : UITextView!
    var favoriteButton : UIButton!
    var eventCollectionView : UICollectionView!
    
    
    var club : Club!
    var events : [Events]!
    
    let padding : CGFloat = 10
    let eventReusableIdentifier = "Events"
    
    init(clubselected: Club){
        self.club = clubselected
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Information"
        view.backgroundColor = .gray
        

        
        //nameLabel
        nameLabel = UILabel()
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.text = club.name
        nameLabel.textAlignment = .center
        nameLabel.textColor = .black
        nameLabel.font = UIFont.systemFont(ofSize: 35, weight: .bold)
        nameLabel.backgroundColor = .gray
        view.addSubview(nameLabel)
        
        //favoriteButton
        favoriteButton = UIButton()
        favoriteButton.translatesAutoresizingMaskIntoConstraints = false
        favoriteButton.setTitle("+", for: .normal)
        favoriteButton.titleLabel?.adjustsFontForContentSizeCategory = true
        favoriteButton.layer.cornerRadius = 4
        favoriteButton.backgroundColor = .cornellred
        view.addSubview(favoriteButton)
        
        //descriptionLabel
        descriptionLabel = UILabel()
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        descriptionLabel.text = "Description"
        descriptionLabel.textAlignment = .left
        descriptionLabel.backgroundColor = .gray
        descriptionLabel.textColor = .black
        descriptionLabel.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        view.addSubview(descriptionLabel)
        
        //officersLabel
        officersLabel = UILabel()
        officersLabel.translatesAutoresizingMaskIntoConstraints = false
        officersLabel.text = "Leaders"
        officersLabel.textAlignment = .left
        officersLabel.backgroundColor = .gray
        officersLabel.textColor = .black
        officersLabel.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        view.addSubview(officersLabel)
        
        //officersText
        officersTextView = UITextView()
        officersTextView.translatesAutoresizingMaskIntoConstraints = false
        officersTextView.backgroundColor = .white
        officersTextView.text = "We did not have time to get this information"
        officersTextView.backgroundColor = .gray
        officersTextView.textColor = .white
        officersTextView.font = UIFont.systemFont(ofSize: 15)
        view.addSubview(officersTextView)
        
        
        //descriptionText
        descriptionText = UITextView()
        descriptionText.translatesAutoresizingMaskIntoConstraints = false
        descriptionText.isScrollEnabled = true
        descriptionText.showsVerticalScrollIndicator = true
        descriptionText.text = club.description
        descriptionText.backgroundColor = .gray
        descriptionText.textColor = .white
        descriptionText.font = UIFont.systemFont(ofSize: 15)
        view.addSubview(descriptionText)
        
        //eventLabel
        eventLabel = UILabel()
        eventLabel.translatesAutoresizingMaskIntoConstraints = false
        eventLabel.text = "Events"
        eventLabel.textAlignment = .left
        eventLabel.backgroundColor = .gray
        eventLabel.textColor = .black
        eventLabel.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        view.addSubview(eventLabel)
        
        // cell Layout
        let eventLayout = UICollectionViewFlowLayout()
        eventLayout.scrollDirection = .horizontal
        eventLayout.minimumLineSpacing = padding
        eventLayout.minimumInteritemSpacing = padding
        
        eventCollectionView = UICollectionView(frame: .zero, collectionViewLayout: eventLayout)
        eventCollectionView.translatesAutoresizingMaskIntoConstraints = false
        eventCollectionView.backgroundColor = .gray
        eventCollectionView.dataSource = self
        eventCollectionView.delegate = self
        eventCollectionView.register(EventCollectionViewCell.self, forCellWithReuseIdentifier: eventReusableIdentifier)
        view.addSubview(eventCollectionView)
        
        
        setupInformationConstraints()
        getEvents(for: club.id)
    }
    
    func setupInformationConstraints() {
        
        //nameLabal setup
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: padding),
            nameLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            nameLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding),
            nameLabel.heightAnchor.constraint(equalToConstant: 50)
            ])
        //officersLabel
        NSLayoutConstraint.activate([
            officersLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            officersLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor),
            officersLabel.heightAnchor.constraint(equalToConstant: 25),
            officersLabel.widthAnchor.constraint(equalToConstant: 300)
            ])
        //favoriteButton
        NSLayoutConstraint.activate([
            favoriteButton.topAnchor.constraint(equalTo: officersLabel.topAnchor),
            favoriteButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding),
            favoriteButton.heightAnchor.constraint(equalTo: officersLabel.heightAnchor),
            favoriteButton.widthAnchor.constraint(equalTo: officersLabel.heightAnchor)
            ])
        //officersTextView
        NSLayoutConstraint.activate([
            officersTextView.topAnchor.constraint(equalTo: officersLabel.bottomAnchor, constant: padding),
            officersTextView.leadingAnchor.constraint(equalTo: officersLabel.leadingAnchor, constant: padding),
            officersTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding),
            officersTextView.heightAnchor.constraint(equalToConstant: 100)
            ])
        //DescriptionLabel
        NSLayoutConstraint.activate([
            descriptionLabel.topAnchor.constraint(equalTo: officersTextView.bottomAnchor, constant: 15),
            descriptionLabel.leadingAnchor.constraint(equalTo: officersLabel.leadingAnchor),
            descriptionLabel.trailingAnchor.constraint(equalTo: officersLabel.trailingAnchor),
            descriptionLabel.heightAnchor.constraint(equalTo: officersLabel.heightAnchor)
            ])
        //descriptionTextView
        NSLayoutConstraint.activate([
            descriptionText.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: padding),
            descriptionText.leadingAnchor.constraint(equalTo: officersTextView.leadingAnchor),
            descriptionText.trailingAnchor.constraint(equalTo: officersTextView.trailingAnchor),
            descriptionText.heightAnchor.constraint(equalTo: officersTextView.heightAnchor)
            ])
        //eventLabel
        NSLayoutConstraint.activate([
            eventLabel.topAnchor.constraint(equalTo: descriptionText.bottomAnchor, constant: padding),
            eventLabel.leadingAnchor.constraint(equalTo: officersLabel.leadingAnchor),
            eventLabel.trailingAnchor.constraint(equalTo: officersLabel.trailingAnchor),
            eventLabel.heightAnchor.constraint(equalTo: officersLabel.heightAnchor)
            ])
        //eventCollectionView
        NSLayoutConstraint.activate([
            eventCollectionView.topAnchor.constraint(equalTo: eventLabel.bottomAnchor, constant: padding),
            eventCollectionView.leadingAnchor.constraint(equalTo: descriptionText.leadingAnchor),
            eventCollectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -padding),
            eventCollectionView.trailingAnchor.constraint(equalTo: descriptionText.trailingAnchor)
            ])
        
    }
    func getEvents(for id: Int){
        NetworkManager.getEvents(id: id) { (response) in
            self.events = response
            DispatchQueue.main.async {
                self.eventCollectionView.reloadData()
            }
        }
        
    }
    
    @objc func buttonPressed() {
      
    }
    
}

extension InformationViewController : UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if (events == nil){
            return 0
        }
        else {
            return events.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = eventCollectionView.dequeueReusableCell(withReuseIdentifier: eventReusableIdentifier, for: indexPath) as! EventCollectionViewCell
        let event = events[indexPath.item]
        cell.configureEventCell(for: event)
        return cell
    }
    
    
}

extension InformationViewController : UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (eventCollectionView.frame.width-10) / 2
        let height = (eventCollectionView.frame.height-40)
        return CGSize(width: width, height: height)
    }
}
