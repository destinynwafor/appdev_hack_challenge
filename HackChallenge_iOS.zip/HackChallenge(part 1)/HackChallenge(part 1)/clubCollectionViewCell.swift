//
//  clubCollectionViewCell.swift
//  HackChallenge(part 1)
//
//  Created by Alvaro on 4/23/19.
//  Copyright © 2019 Alvaro Echevarria Cuesta. All rights reserved.
//

import UIKit

class clubCollectionViewCell: UICollectionViewCell {
    var backGroundView: UIView!
    var mainView : UIView!
    
    var nameLabel : UILabel!
    var leftLabel : UILabel!
    var rightLabel : UILabel!
    var topLabel : UILabel!
    var bottomLabel : UILabel!
    
    let boundarySize : CGFloat = 2
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.layer.cornerRadius = 10
        backgroundColor = .gray
        
        //backgroundView
        backGroundView = UIView()
        backGroundView?.translatesAutoresizingMaskIntoConstraints = false
        backGroundView?.backgroundColor = .white
        backGroundView.layer.cornerRadius = 7
        contentView.addSubview(backGroundView)
        
        //mainView
        mainView = UIView()
        mainView.translatesAutoresizingMaskIntoConstraints = false
        mainView.layer.cornerRadius = 7
        mainView.backgroundColor = .black
        backGroundView.addSubview(mainView)
        
        
        //nameLabel
        nameLabel = UILabel()
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.backgroundColor = .black
        nameLabel.textAlignment = .center
        nameLabel.textColor = .white
        nameLabel.font = UIFont.systemFont(ofSize: 20, weight: .heavy)
        mainView.addSubview(nameLabel)
        
        
        setupConstraints()
    }
    
    func setupConstraints() {
        //backGroundView
        NSLayoutConstraint.activate([
            backGroundView.topAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.topAnchor),
            backGroundView.bottomAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.bottomAnchor),
            backGroundView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            backGroundView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
            ])
        //mainView
        NSLayoutConstraint.activate([
            mainView.topAnchor.constraint(equalTo: backGroundView.topAnchor, constant: 3),
            mainView.bottomAnchor.constraint(equalTo: backGroundView.bottomAnchor, constant: -3),
            mainView.leadingAnchor.constraint(equalTo: backGroundView.leadingAnchor, constant: 3),
            mainView.trailingAnchor.constraint(equalTo: backGroundView.trailingAnchor, constant: -3)
            ])

        //nameLabel
        NSLayoutConstraint.activate([
            nameLabel.centerXAnchor.constraint(equalTo: mainView.centerXAnchor),
            nameLabel.centerYAnchor.constraint(equalTo: mainView.centerYAnchor),
            nameLabel.leadingAnchor.constraint(equalTo: mainView.leadingAnchor,constant: 5),
            nameLabel.topAnchor.constraint(equalTo: mainView.topAnchor, constant: 5)
            ])
    }
    
    func configure(for name: String){
        nameLabel.text = name
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
