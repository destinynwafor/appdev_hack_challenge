//
//  MainTabBarController.swift
//  HackChallenge(part 1)
//
//  Created by Alvaro on 4/28/19.
//  Copyright © 2019 Alvaro Echevarria Cuesta. All rights reserved.
//

import UIKit

class MainTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let clubSearchViewController = UIViewController()
        
        clubSearchViewController.tabBarItem = UITabBarItem(tabBarSystemItem: .search , tag: 0)
        
        
        let personalViewController = UIViewController()
        
        personalViewController.tabBarItem = UITabBarItem(tabBarSystemItem: .more, tag: 1)
        
        let tabBarList = [clubSearchViewController, personalViewController]
        
        viewControllers = tabBarList
    }
    

}
