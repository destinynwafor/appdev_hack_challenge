//
//  EventCollectionViewCell.swift
//  HackChallenge(part 1)
//
//  Created by Alvaro on 5/5/19.
//  Copyright © 2019 Alvaro Echevarria Cuesta. All rights reserved.
//

import UIKit

class EventCollectionViewCell: UICollectionViewCell {
    var nameLabel : UILabel!
    var startLabel : UILabel!
    var endLabel : UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        //nameLabel
        nameLabel = UILabel()
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.backgroundColor = .black
        nameLabel.textColor = .white
        nameLabel.textAlignment = .center
        contentView.addSubview(nameLabel)
        
        //startLabel
        startLabel = UILabel()
        startLabel.translatesAutoresizingMaskIntoConstraints = false
        startLabel.backgroundColor = .black
        startLabel.textColor = .white
        startLabel.textAlignment = .center
        contentView.addSubview(startLabel)
        
        //endLabel
        endLabel = UILabel()
        endLabel.translatesAutoresizingMaskIntoConstraints = false
        endLabel.backgroundColor = .black
        endLabel.textColor = .white
        endLabel.textAlignment = .center
        contentView.addSubview(endLabel)
        
        
        
        setupConstraints()
    }
    
    func setupConstraints() {
        //nameLabel
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.topAnchor),
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            nameLabel.heightAnchor.constraint(equalToConstant: 25)
            
            ])
        //startLabel
        NSLayoutConstraint.activate([
            startLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor),
            startLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            startLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            startLabel.heightAnchor.constraint(equalToConstant: 25)
            ])
        //endLabel
        NSLayoutConstraint.activate([
            endLabel.topAnchor.constraint(equalTo: startLabel.bottomAnchor),
            endLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            endLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            endLabel.heightAnchor.constraint(equalToConstant: 25)
            ])
    }
    
    func configureEventCell(for event: Events) {
        nameLabel.text = event.description
        startLabel.text = event.start_datetime
        endLabel.text = event.end_datetime
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
