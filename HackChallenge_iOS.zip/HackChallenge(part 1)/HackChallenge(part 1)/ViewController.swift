//
//  ViewController.swift
//  HackChallenge(part 1)
//
//  Created by Alvaro on 4/23/19.
//  Copyright © 2019 Alvaro Echevarria Cuesta. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var filterTextField : UITextField!
    var clubCollectionView : UICollectionView!
    var searchButton: UIButton!
    var clubs : [Club]!
    
    var clubArray : [String]!
    var displayClubArray : [String]!
    
    var hardcodedClubs : [Club]!
    
    let clubReuseIdentifier : String = "clubs"
    let padding : CGFloat = 10
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        title = "Cornell Clubs"
        view.backgroundColor = .gray
        
        
        

        
        //filterTextField
        filterTextField = UITextField()
        filterTextField.translatesAutoresizingMaskIntoConstraints = false
        filterTextField.placeholder = "Search"
        filterTextField.borderStyle = .roundedRect
        filterTextField.clearsOnBeginEditing = true
        view.addSubview(filterTextField)
        
        //searchButton
        searchButton = UIButton()
        searchButton.translatesAutoresizingMaskIntoConstraints = false
        searchButton.setTitle("Search", for: .normal)
        searchButton.setTitleColor(.black, for: .normal)
        searchButton.titleLabel?.adjustsFontSizeToFitWidth = true
        searchButton.layer.cornerRadius = 10
        searchButton.backgroundColor = .cornellred
        searchButton.addTarget(self, action: #selector(searchButtonPressed), for: .touchUpInside)
        view.addSubview(searchButton)
        
        
        
        // cell Layout
        let clubLayout = UICollectionViewFlowLayout()
        clubLayout.scrollDirection = .vertical
        clubLayout.minimumLineSpacing = padding
        clubLayout.minimumInteritemSpacing = padding
        
        
        //clubCollectionView
        clubCollectionView = UICollectionView(frame: .zero, collectionViewLayout: clubLayout)
        clubCollectionView.translatesAutoresizingMaskIntoConstraints = false
        clubCollectionView.backgroundColor = .gray
        clubCollectionView.dataSource = self
        clubCollectionView.delegate = self
        clubCollectionView.register(clubCollectionViewCell.self, forCellWithReuseIdentifier: clubReuseIdentifier)
        view.addSubview(clubCollectionView)
        
        setupConstraints()
        getClubs()
    }

    func setupConstraints () {
        
        //filterTextField setup constraints
        NSLayoutConstraint.activate([
            filterTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: padding),
            filterTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            filterTextField.trailingAnchor.constraint(equalTo: searchButton.leadingAnchor, constant: -padding),
            filterTextField.heightAnchor.constraint(equalToConstant: 30)
            ])
        //searchButton setup constraints
        NSLayoutConstraint.activate([
            searchButton.topAnchor.constraint(equalTo: filterTextField.topAnchor),
            searchButton.bottomAnchor.constraint(equalTo: filterTextField.bottomAnchor),
            searchButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding),
            searchButton.widthAnchor.constraint(equalToConstant: 65)
            ])
        //clubCollectionView setup constraints
        NSLayoutConstraint.activate([
            clubCollectionView.topAnchor.constraint(equalTo: filterTextField.bottomAnchor, constant: 2*padding),
            clubCollectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            clubCollectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding),
            clubCollectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -padding)
            ])
    }
    
    func getClubs() {
        NetworkManager.getClubs { (clubs) in
            self.clubs = clubs
            DispatchQueue.main.async {
                self.clubCollectionView.reloadData()
            }
        }
        
    }
    
    @objc func searchButtonPressed()  {
        let name = filterTextField.text
        filterTextField.text = ""
        if (name == ""){
            getClubs()
        }
        else {
            if (clubs == nil) {}
            else{
            let length = (clubs.count)-1
            for i in 0...(length){
                if (name == clubs[i].name) {
                    clubs = [clubs[i]]
                    clubCollectionView.reloadData()
                    break
                }
            }
        }
        
    }
    }
    
}

extension ViewController : UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if clubs == nil {
            return 0
        }
        else{
        return clubs.count
        }
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = clubCollectionView.dequeueReusableCell(withReuseIdentifier: clubReuseIdentifier, for: indexPath) as! clubCollectionViewCell
        let clubname = clubs[indexPath.item].name
        
        cell.configure(for: clubname)
        
        return cell
    }
}

extension ViewController : UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let side = (clubCollectionView.frame.width-10) / 4
        return CGSize(width: (4*side), height: (side))
    }
}

extension ViewController : UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let club = clubs[indexPath.item]
        let informationViewController = InformationViewController(clubselected: club)
        navigationController?.pushViewController(informationViewController, animated: true)
    }
}
