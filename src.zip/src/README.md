# appdev_hack_challenge
AppDev Hack Challenge: Cornell Events 
